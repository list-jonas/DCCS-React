import {Movie} from "../../common/models/movie.model";
import "./MovieDetails.styles.css"
import {useState} from "react";

interface MovieDetailsProps {
    movie: Movie | undefined
}

const initMovie: Movie = {
    title: "",
    description: "",
    imageUrl: "",
    isFavorite: false,
    isWatched: false
}

const MovieDetails: React.FC<MovieDetailsProps> = (props) => {
    const { movie } = props
    const [ formState, setFormState ] = useState<Movie>(movie ?? initMovie)


    return (
        <div className={"movie-details-root"}>
            <div className="movie-details-header">
                <span>{"Add movie"}</span>
            </div>

            <div className="movie-details-content">
                <div className="movie-details-img-container">
                    <img src={formState.imageUrl} alt="None"/>
                </div>
                <div className="movie-details-form-container">
                    <div className="movie-details-from-field">
                        <label>Title</label>
                        <input
                            type="text"
                            maxLength={50}
                            value={formState.title}
                            onChange={e => {}}
                        />
                    </div>
                    <div className="movie-details-from-field">
                        <label>Genre</label>
                    </div>
                    <div className="movie-details-from-field">
                        <label>Year</label>
                        <input
                            type="number"
                            min={1900}
                            max={2023}
                            value={formState.year}
                            onChange={e => {}}
                        />
                    </div>
                    <div className="movie-details-from-field">
                        <label>Description</label>
                        <input
                            type="text"
                            maxLength={200}
                            value={formState.description}
                            onChange={e => {}}
                        />
                    </div>
                    <div className="movie-details-from-field">
                        <label>Image url</label>
                        <input
                            type="text"
                            value={formState.imageUrl}
                            onChange={e => {}}
                        />
                    </div>
                </div>
            </div>

            <div className="movie-details-button-container">
                <button className="movie-details-cancel-button" onClick={() => {}}>Cancel</button>
                <button
                    className="movie-details-save-button"
                    onClick={() => {}}
                    disabled={true}
                >Save
                </button>
            </div>
        </div>
    )
}

export default MovieDetails